//RecommenderSystem.h
/**
* @file RecommenderSystem.h
* @author shahar cohen <shahar.cohen10@mail.huji.ac.il>
* @cs user: shaharc1994
* @id 205801541
* @brief ex5,algorithm STL (=
*/
// define
# ifndef PROJECT5_RECOMMENDERSYSTEM_H
# define PROJECT5_RECOMMENDERSYSTEM_H
// include
# include <string>
# include <vector>
# include <map>
# include <functional>
# include <unordered_map>
# include <sstream>
// using
using std :: istringstream;
using std :: vector;
using std :: string;
/**
 * this class represent tools for a movies theater company to  attract customers
 * is have a uniq and secret algorithm that can tell the customer what is the best movie for him
 * and by doing it is collect data from the users the keep update and refresh the movies from the
 * date that class receive
 */
class RecommenderSystem
{
/**
* private methods to support the main algorithms
*/
private:
	/**
	 * represent by unordered map structure the movie(string) and his characteristics(vector)
	 */
	std::unordered_map<string, vector<double>> _dataMovieAttributes;
	/**
	 * represent by unordered map structure the user name(string) and his movies rank(vector)
	 */
	std::unordered_map<string, vector<double>> _dataUserRanks;
	/**
	 * represent by vector structure the movies in the order they show in user rank
	 */
	vector<string> _movieByOrder;
	/**
    * represent by unordered map structure the movies and their norms
 	*/
	std::unordered_map<std::string, double> _moviesNorm;
	/**
 	* represent by int how many Characteristics define each movie
 	*/
	int Characteristics;
	/**
 	* this method calculate the imagination between two recommend vector and movie attributes vector
 	* @param vecA
 	* @param vecB
 	* @return imagination rank
	 */
	double _imageByVec(vector <double > &vecA, const string& MovieName, double norm);
	/**
 	* this methods return the user recommend vector by the exercise instructions
 	* @param userName
 	* @return double vector
 	*/
	vector<double> _recommendVec(const string& userName);
	/**
 	* this methods multiples vector in scalar
 	* @param vec
 	* @param scalar
 	* @return double vector
 	*/
	static vector<double> _mulVecScalar(vector<double> &vec, double &scalar);
	/**
 	* this method return the movies the user watch
 	* @param userName
 	* @return string vector
 	*/
	vector<string> _watched(const string& userName);
	/**
 	* this method return the movies the user didnt watch
	* @param userName
	* @return string vector
 	*/
	vector<string> _unWatched(const string& userName);
	/**
 	* this methods norm the vector
 	* @param userName
 	* @return double vector
 	*/
	vector<double> _normalVec(const string& userName);
	/**
 	* this methods is helper for the public method "predictMovieScoreForUser"
 	* make the method more clear return the most suitable rank by k movies
 	* @param movieName
 	* @param userName
 	* @param k
 	* @return double
 	*/
	double _preRankByK(const string& movieName, const string& userName, int k);
	/**
 	* this methods is a helper to get the max val in a map structure by val
 	* @param pA
 	* @param pB
 	* @return int
 	*/
	static int _compM(const std :: pair<int, double> &pA, const std ::pair<int, double> &pB);
	/**
	* this method is helper to "loadData" it work on movie,Characteristics file read the data
	* and store the data.
	* @param userRanksFilePath
	* @return 0 success,-1 Failure
	*/
	int _loadDFileOne(const string& movieAttributesFilePath);
	/**
 	* this method is helper to "loadData" it work on the user rank,movie order file read the data
 	* and store the data.
 	* @param userRanksFilePath
 	* @return 0 success,-1 Failure
 	*/
	int _loadDFileTwo(const string& userRanksFilePath);
	/**
 	* this methods find the movie normal
	* @param movieName
	* @return double
 	*/
	double _getMN(const string& movieName);
	/**
 	* this method calculate the imagination between two movie attributes vectors
 	* @param vecA
 	* @param vecB
 	* @return imagination rank
 	*/
	double _imageByMovies(const string& nM1, const string& nM2);
/**
 * exercise instructions algorithm
 */
public:
	/**
 	* this method receive two input string containing the path of the files, read the information
 	* from the file to the class "RecommenderSystem"
 	* @param movieAttributesFilePath
 	* @param userRanksFilePath
 	* @return 0 success;-1 failure
 	*/
	int loadData(const std::string& movieAttributesFilePath, const std::string& userRanksFilePath);
	/**
	 * this method receive string user name and by using algorithm return the most recommended
 	* movie for the user if the user not found it will return -1
 	* @param userName
 	* @return string,-1 failure
 	*/
	string recommendByContent(const string& userNAme);
	/**
 	* this methods receive two strings user name, movie name and integer by using the k most
 	* similar movies image and special algorithm its return the pre rank that the user give to the
 	* movie if the user not found it will return -1
 	* @param movieName
 	* @param userName
 	* @param k
 	* @return double, -1 failure
 	*/
	double predictMovieScoreForUser(const string& movieName, const string& userName, int k);
	/**
 	* this method receive string movie name and a integer by using the k highest rank movie and the
 	* method "predictMovieScoreForUser" it find the most recommended movie for the user
 	* @param userName
 	* @param k
 	* @return string
 	*/
	string recommendByCF(const string& userName, int k);
};
#endif //PROJECT5_RECOMMENDERSYSTEM_H
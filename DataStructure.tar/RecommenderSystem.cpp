/**
* @file RecommenderSystem.cpp
* @author shahar cohen <shahar.cohen10@mail.huji.ac.il>
* @cs user: shaharc1994
* @id 205801541
* @brief ex5,algorithm STL (=
*/
// include
# include <iostream>
# include <fstream>
# include <vector>
# include <string>
# include <cmath>
# include "RecommenderSystem.h"
# include <algorithm>
# include <numeric>
# include <unordered_map>
// using
using std :: string;
using std :: istringstream;
using std :: map;
using std :: vector;



// macro
# define FAILURE -1
# define SUCCESS 0
# define ERROR_FILE "Unable to open file "
# define ERROR_USER "USER NOT FOUND"
// private class methods
/**
 * this method calculate the imagination between two movie attributes vectors
 * @param vecA
 * @param vecB
 * @return imagination rank
 */
double RecommenderSystem :: _imageByMovies(const string& nM1, const string& nM2)
{
	double num = inner_product(_dataMovieAttributes[nM1].begin(),
							   _dataMovieAttributes[nM1].end(),
							   _dataMovieAttributes[nM2].begin(), 0.0);
	double den = (_moviesNorm[nM1] * _moviesNorm[nM2]);
	return num / den;
}
/**
 * this methods find the movie normal
 * @param movieName
 * @return double
 */
double RecommenderSystem :: _getMN(const string& movieName)
{
	double inp = inner_product(_dataMovieAttributes[movieName].begin(),
			                  _dataMovieAttributes[movieName].end(),
			                  _dataMovieAttributes[movieName].begin(), 0.0);
	double norm = sqrt(inp);
	return norm;
}
/**
 * this method calculate the imagination between two recommend vector and movie attributes vector
 * @param norm vecA
 * @param vecA
 * @param movie name to get the vec
 * @return imagination rank
 */
double RecommenderSystem :: _imageByVec(vector <double > &vecA, const string& movieName,
		                                const double norm)
{
	double tN = std :: inner_product(vecA.begin(), vecA.end(), _dataMovieAttributes[movieName]
	.begin(), 0.0);
	double sB = _moviesNorm[movieName];
	double par = norm * sB;
	double res = (tN / par);
	return res;
}
/**
 * this method return the movies the user watch
 * @param userName
 * @return string vector
 */
vector<string>  RecommenderSystem :: _watched(const string& userName)
{
	vector <string> watchedV;
	for (long unsigned int i = 0; i < _dataUserRanks[userName].size() ; i++)
	{
		if (_dataUserRanks[userName][i] != 0)
		{
			watchedV.push_back(_movieByOrder[i]);
		}
	}
	return watchedV;
}
/**
 * this method return the movies the user didnt watch
 * @param userName
 * @return string vector
 */
vector<string>  RecommenderSystem :: _unWatched(const string& userName)
{
	vector <string> watchedV;
	for (long unsigned int i = 0; i < _dataUserRanks[userName].size() ; i++)
	{
		if (_dataUserRanks[userName][i] == 0)
		{
			watchedV.push_back(_movieByOrder[i]);
		}
	}
	return watchedV;
}
/**
 * this methods multiples vector in scalar
 * @param vec
 * @param scalar
 * @return double vector
 */
vector<double> RecommenderSystem :: _mulVecScalar(vector<double> &vec, double &scalar)
{
	for (double & i : vec)
	{
		i = i * scalar;
	}
	return vec;
}
/**
 * this methods norm the vector
 * @param userName
 * @return double vector
 */
vector<double> RecommenderSystem :: _normalVec(const string& userName)
{
	vector<double> oldV = _dataUserRanks[userName];
	vector<string> watchedV = _watched(userName);
	double oldVSum = std :: accumulate(oldV.begin(), oldV.end(), decltype(oldV) ::
	value_type(0));
	double oldVAvg = (oldVSum / watchedV.size());
	for (double & i : oldV)
	{
		if (i != 0)
		{
			i -= oldVAvg;
		}
	}
	return oldV;
}
/**
 * this methods return the user recommend vector by the exercise instructions
 * @param userName
 * @return double vector
 */
vector<double> RecommenderSystem ::_recommendVec(const string& userName)
{
	vector <double> normV = _normalVec(userName);
	vector<double> recV(Characteristics);
	std :: fill(recV.begin(), recV.end(), 0);
	for (long unsigned int i = 0; i < normV.size(); i++)
	{
		if (normV[i] != 0)
		{
			vector<double> mVec = _dataMovieAttributes[_movieByOrder[i]];
			vector<double> tempV = _mulVecScalar(mVec, normV[i]);
			std :: transform(recV.begin(), recV.end(), tempV.begin(), recV.begin(), std::
			plus<>());
		}
	}
	return recV;
}
/**
 * this methods is a helper to get the max val in a map structure by val
 * @param pA
 * @param pB
 * @return int
 */
int RecommenderSystem :: _compM(const std :: pair<int, double> &pA, const std ::pair<int,
		                        double>&pB)
{
	return pB.second > pA.second;
}
/**
 * this methods is helper for the public method "predictMovieScoreForUser"
 * make the method more clear return the most suitable rank by k movies
 * @param movieName
 * @param userName
 * @param k
 * @return double
 */
double RecommenderSystem :: _preRankByK(const string& movieName, const string&
                                        userName, const int k)
{
	std :: unordered_map<int, double> movieSim;
	vector<double> curMV = _dataMovieAttributes[movieName];
	vector<int> vecKS;
	for (long unsigned int i = 0; i < _movieByOrder.size() ; i++)
	{
		if (_dataUserRanks[userName][i] != 0)
		{
			double tempN = _imageByMovies(movieName, _movieByOrder[i]);
			movieSim[i] = tempN;
		}
	}
	double numerator = 0.0;
	double denominator = 0.0;
	for (int i = 0; i < k; i++)
	{
		auto mPart = std :: max_element(movieSim.begin(), movieSim.end(), _compM);
		denominator += (mPart->second);
		numerator +=  ((mPart->second) * (_dataUserRanks[userName][mPart->first]));
		movieSim.erase(mPart->first);
	}
	return numerator / denominator;
}
/**
 * this method is helper to "loadData" it work on movie,Characteristics file read the data
 * and store the data.
 * @param userRanksFilePath
 * @return 0 success,-1 Failure
 */
int RecommenderSystem :: _loadDFileOne(const string& movieAttributesFilePath)
{
	istringstream lineISA, lineISB;
	std::ifstream firstFile;
	firstFile.open(movieAttributesFilePath);
	if (firstFile.fail())
	{
		std::cerr << ERROR_FILE << movieAttributesFilePath  << std::endl;
		return FAILURE;
	}
	string line1, movieN, scoreS;
	double score;
	vector<double> scoreV;
	while (getline(firstFile, line1))
	{
		lineISA.clear();
		lineISB.clear();
		lineISA.str(line1);
		lineISA >> movieN;
		while (lineISA >> scoreS)
		{
			lineISB.str(scoreS);
			lineISB >> score;
			lineISB.clear();
			scoreV.push_back(score);
		}
		_dataMovieAttributes[movieN] = scoreV;
		scoreV.clear();
	}
	firstFile.close();
	Characteristics = _dataMovieAttributes[movieN].size();
	return SUCCESS;
}
/**
 * this method is helper to "loadData" it work on the user rank,movie order file read the data
 * and store the data.
 * @param userRanksFilePath
 * @return 0 success,-1 Failure
 */
int RecommenderSystem :: _loadDFileTwo(const string& userRanksFilePath)
{
	istringstream lineISA, lineISB;
	std::ifstream secondFile;
	secondFile.open(userRanksFilePath);
	if (secondFile.fail())
	{
		std:: cerr << ERROR_FILE << userRanksFilePath << std::endl;
		return FAILURE;
	}
	string line, tempMovie;
	getline(secondFile, line);
	lineISA.str(line);
	lineISA.clear();
	while (lineISA >> tempMovie)
	{
		_movieByOrder.push_back(tempMovie);
		_moviesNorm[tempMovie] = _getMN(tempMovie);
	}
	string name, rankS;
	double rank;
	vector<double> rankV;
	while (getline(secondFile, line))
	{
		lineISA.clear();
		lineISA.str(line);
		lineISA >> name;
		while (lineISA >> rankS)
		{
			if (rankS == "NA")
			{
				rankV.push_back(0.0);
			}
			else
			{
				lineISB.clear();
				lineISB.str(rankS);
				lineISB >> rank;
				rankV.push_back(rank);
			}
		}
		_dataUserRanks[name] = rankV;
		rankV.clear();
	}
	secondFile.close();
	return SUCCESS;
}
// public class methods
/**
 * this method receive two input string containing the path of the files, read the information
 * from the file to the class "RecommenderSystem"
 * @param movieAttributesFilePath
 * @param userRanksFilePath
 * @return 0 success;-1 failure
 */
int RecommenderSystem :: loadData(const string& movieAttributesFilePath, const string&
                                  userRanksFilePath)
{
	if (_loadDFileOne(movieAttributesFilePath) == FAILURE || _loadDFileTwo(userRanksFilePath) ==
		FAILURE)
	{
		return FAILURE;
	}
	return SUCCESS;
}
/**
 * this method receive string user name and by using algorithm return the most recommended
 * movie for the user if the user not found it will return -1
 * @param userName
 * @return string,-1 failure
 */
string RecommenderSystem :: recommendByContent(const string& userName)
{
	if (_dataUserRanks.find(userName) == _dataUserRanks.end())
	{
		return ERROR_USER;
	}
	vector<double> recV = _recommendVec(userName);
	double norm = sqrt(inner_product(recV.begin(), recV.end(), recV.begin(), 0.0));
	vector<string> userUW = _unWatched(userName);
	double topRec = -2;
	string topRecS;
	for (const auto & i : userUW)
	{
		double tempN = _imageByVec(recV, i, norm);
		if (tempN == topRec)
		{
			continue;
		}
		else if (tempN > topRec)
		{
			topRec = tempN;
			topRecS = i;
		}
	}
	return topRecS;
}
/**
 * this methods receive two strings user name, movie name and integer by using the k most
 * similar movies image and special algorithm its return the pre rank that the user give to the
 * movie if the user not found it will return -1
 * @param movieName
 * @param userName
 * @param k
 * @return double, -1 failure
 */
double RecommenderSystem :: predictMovieScoreForUser(const string& movieName, const string&
                                                     userName, int k)
{
	if (_dataMovieAttributes.find(movieName) == _dataMovieAttributes.end() ||
		_dataUserRanks.find(userName) == _dataUserRanks.end())
	{
		return FAILURE;
	}
	return _preRankByK(movieName, userName, k);
}
/**
 * this method receive string movie name and a integer by using the k highest rank movie and the
 * method "predictMovieScoreForUser" it find the most recommended movie for the user
 * @param userName
 * @param k
 * @return string
 */
string RecommenderSystem :: recommendByCF(const string& userName, int k)
{
	if (_dataUserRanks.find(userName) == _dataUserRanks.end())
	{
		return ERROR_USER;
	}
	double suitableR = 0.0;
	string suitableM;
	vector<string> unWatch = _unWatched(userName);
	for (const auto & i : unWatch)
	{
		double tempD = predictMovieScoreForUser(i, userName, k);
		if (tempD > suitableR)
		{
			suitableR = tempD;
			suitableM = i;
		}
	}
	return suitableM;
}
